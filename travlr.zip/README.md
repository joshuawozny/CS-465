# CS-465

## Course Description

Students will design and develop a full stack application through the utilization of programming language frameworks. In creating a full stack application, students will also be responsible for developing a database as well as the code that interfaces their application to the database. This course is the first course in a two-course sequence.

![image](https://github.com/joshuawozny/CS-465/assets/108596884/4e744520-8a89-43e6-a3a1-2d6f4a5af0d1)
![image](https://github.com/joshuawozny/CS-465/assets/108596884/bc192f4a-31b7-4a6a-87c3-6c3bd9e1b3d9)
